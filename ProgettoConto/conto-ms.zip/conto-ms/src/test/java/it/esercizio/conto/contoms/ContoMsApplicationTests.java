package it.esercizio.conto.contoms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContoMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
